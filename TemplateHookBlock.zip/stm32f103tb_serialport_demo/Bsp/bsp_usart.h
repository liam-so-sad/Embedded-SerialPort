#include "serialport.h"

#define   RECV_FIFO_SIZE			512
#define   ANCHOR_FIFO_SIZE		10

extern Serial_HandleTypeDef  myserial;

void   SerialPortFrameworkInit();
void   HookFunctionDemo();

void debug_printf(const char *format, ...);
